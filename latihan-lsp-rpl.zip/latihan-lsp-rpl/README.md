LSP RPL 2024

admin@example.com  
123123123

fitra@latian.com
fitra123

halaman dashboard jika ada sidebar

<?php

include '../auth/auth.php';
checkAuth(); // Cek apakah admin sudah login
include '../config/db.php'; // Koneksi ke database

// Menghitung total vendor
$stmt = $conn->query("SELECT COUNT(*) AS total_vendor FROM vendor");
$total_vendor = $stmt->fetchColumn();

// Menghitung total inventory
$stmt = $conn->query("SELECT COUNT(*) AS total_inventory FROM inventory");
$total_inventory = $stmt->fetchColumn();

// Menghitung total storage unit
$stmt = $conn->query("SELECT COUNT(*) AS total_storage_unit FROM storage_unit");
$total_storage_unit = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <title>Dashboard</title>
    <style>
        .card-custom {
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .card-header-custom {
            font-size: 1.2rem;
            font-weight: bold;
        }

        .dashboard-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: #333;
        }

        .btn-custom {
            background-color: rgba(255, 255, 255, 0.8);
            color: #333;
            border: none;
        }

        .btn-custom:hover {
            background-color: rgba(255, 255, 255, 1);
            color: #007bff;
        }
    </style>
</head>
<body>
<?php
include '../partials/header.php'; // Memanggil header
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3">
           
        </div>
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center mt-4">
                <h1 class="dashboard-title">Dashboard</h1>
                <p>Welcome to the admin panel!</p>
            </div>

            <div class="row mt-4">
                <div class="col-md-4">
                    <div class="card card-custom text-white bg-info mb-3">
                        <div class="card-header card-header-custom">Total Vendors</div>
                        <div class="card-body">
                            <h5 class="card-title display-4"><?php echo $total_vendor; ?></h5>
                            <a href="vendor_list.php" class="btn btn-custom">Manage Vendors</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-custom text-white bg-success mb-3">
                        <div class="card-header card-header-custom">Total Inventory Items</div>
                        <div class="card-body">
                            <h5 class="card-title display-4"><?php echo $total_inventory; ?></h5>
                            <a href="inventory_list.php" class="btn btn-custom">Manage Inventory</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-custom text-white bg-warning mb-3">
                        <div class="card-header card-header-custom">Total Storage Units</div>
                        <div class="card-body">
                            <h5 class="card-title display-4"><?php echo $total_storage_unit; ?></h5>
                            <a href="storage_unit_list.php" class="btn btn-custom">Manage Storage Units</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../partials/footer.php'; // Memanggil footer ?>
</body>
</html>
