<!-- partials/header.php -->
<nav class="navbar navbar-expand-lg navbar-light bg-primary shadow-sm">
    <a class="navbar-brand text-white font-weight-bold mx-4" href="#">
        <i class="fas fa-warehouse"></i> <b>Inventory Management</b>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item mx-2">
                <a href="dashboard.php" class="nav-link btn btn-danger text-white rounded-pill px-3 d-flex align-items-center py-2">
                    <i class="fas fa-tachometer-alt mr-1"></i> Dashboard
                </a>
            </li>
            <li class="nav-item mx-2">
                <a href="vendor_list.php" class="nav-link btn btn-danger text-white rounded-pill px-3 d-flex align-items-center py-2">
                    <i class="fas fa-truck mr-1"></i> Vendor
                </a>
            </li>
            <li class="nav-item mx-2">
                <a href="inventory_list.php" class="nav-link btn btn-danger text-white rounded-pill px-3 d-flex align-items-center py-2">
                    <i class="fas fa-boxes mr-1"></i> Inventory
                </a>
            </li>
            <li class="nav-item mx-2">
                <a href="storage_unit.php" class="nav-link btn btn-danger text-white rounded-pill px-3 d-flex align-items-center py-2">
                    <i class="fas fa-warehouse mr-1"></i> Gudang
                </a>
            </li>
            <li class="nav-item mx-2">
                <a class="nav-link btn btn-danger text-white rounded-pill px-3 d-flex align-items-center py-2" href="../auth/logout.php">
                    <i class="fas fa-sign-out-alt mr-1"></i> Logout
                </a>
            </li>
        </ul>
    </div>
</nav>

<!-- Optional CSS for styling -->
<style>
    .navbar {
        background-color: #0056b3;
    }
    .navbar-brand {
        font-size: 1.5rem;
    }
    .navbar-nav .nav-link {
        transition: transform 0.2s, background-color 0.3s ease;
    }
    .navbar-nav .nav-link:hover {
        background-color: #17a2b8; /* bootstrap "bg-info" color */
        transform: scale(1.05); /* Slight scaling effect */
    }
    .btn {
        font-size: 1rem;
    }
</style>

<!-- FontAwesome for icons (optional, remove if unnecessary) -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
