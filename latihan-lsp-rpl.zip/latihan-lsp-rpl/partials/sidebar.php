<div class="sidebar-wrapper">
  <div class="d-flex flex-column flex-shrink-0 bg-white shadow-sm sidebar" style="width: 280px; height: 100vh;">
    <div class="p-3">
      <a href="#" class="d-flex align-items-center pb-3 mb-3 link-dark text-decoration-none border-bottom">
        <span class="fs-5 fw-semibold">Menu Admin</span>
      </a>
      
      <ul class="nav nav-pills flex-column mb-auto gap-2">
        <li class="nav-item">
          <a href="dashboard.php" class="nav-link active">
            <i class="bi bi-speedometer2 me-2"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item">
          <a href="inventory_list.php" class="nav-link">
            <i class="bi bi-box-seam me-2"></i>
            <span>Inventory</span>
          </a>
        </li>
        <li class="nav-item">
          <a href="vendor_list.php" class="nav-link">
            <i class="bi bi-people me-2"></i>
            <span>Vendor</span>
          </a>
        </li>
        <li class="nav-item">
          <a href="storage_unit.php" class="nav-link">
            <i class="bi bi-building me-2"></i>
            <span>Gudang</span>
          </a>
        </li>
      </ul>
    </div>
  </div>
</div>

<style>
.sidebar {
  transition: all 0.3s ease;
  border-right: 1px solid rgba(0,0,0,.1);
}

.sidebar .nav-link {
  color: #333;
  border-radius: 8px;
  padding: 0.8rem 1rem;
  font-weight: 500;
  display: flex;
  align-items: center;
  transition: all 0.3s ease;
}

.sidebar .nav-link:hover {
  background-color: rgba(13, 110, 253, 0.1);
  color: #0d6efd;
}

.sidebar .nav-link.active {
  background-color: #0d6efd;
  color: white;
}

.sidebar .nav-link.active:hover {
  color: white;
}

.sidebar .nav-link i {
  font-size: 1.1rem;
  opacity: 0.8;
}

.sidebar .border-bottom {
  border-bottom-color: rgba(0,0,0,.1) !important;
}

.sidebar .border-top {
  border-top-color: rgba(0,0,0,.1) !important;
}
</style>