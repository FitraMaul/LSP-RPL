<?php
include '../auth/auth.php';
checkAuth(); // Cek apakah admin sudah login
include '../config/db.php'; // Koneksi ke database
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <title>Dashboard</title>
    <style>
        .dashboard-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 50px;
        }

        .dashboard-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: #333;
            text-align: center;
        }

        .dashboard-subtitle {
            font-size: 1.2rem;
            color: #666;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<?php include '../partials/header.php'; // Memanggil header ?>

<div class="container-fluid">
    <div class="dashboard-container">
        <h1 class="dashboard-title">Admin Dashboard</h1>
        <p class="dashboard-subtitle">Welcome to the admin panel! Manage your application efficiently.</p>
    </div>
</div>

<?php include '../partials/footer.php'; // Memanggil footer ?>
</body>
</html>  
