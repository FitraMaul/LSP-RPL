<?php


// ini statement

?>




<?php include '../partials/header.php';?>
<?php include '../partials/sidebar.php';?>

<!-- ini content -->
 

<?php include '../partials/footer.php';?>