<?php

header("Location: views/dashboard.php");
exit();
