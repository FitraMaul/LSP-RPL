<!-- partials/footer.php -->
</div>
</div>
</div>
<footer class="text-center py-4">
    <p>&copy; <?php echo date("Y"); ?> Inventory Management System. All rights reserved.</p>
</footer>

<script src="../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
