<div class="container-fluid">
    <div class="row">
<div class="col-2">
<div class="bg-light" style="height: 100vh;">
    <div class="p-3">
        <h5>Menu</h5>
        <hr>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link">Dashboard</a>
            </li>
            <li class="nav-item">
                <a href="inventory_list.php" class="nav-link">Inventory</a>
            </li>
            <li class="nav-item">
                <a href="vendor_list.php" class="nav-link">Vendor</a>
            </li>
            <li class="nav-item">
                <a href="storage_unit.php" class="nav-link">Gudang</a>
            </li>
        </ul>
    </div>
</div>

</div>
<!-- partials/sidebar.php -->

<!-- content -->

<div class="col-10">
